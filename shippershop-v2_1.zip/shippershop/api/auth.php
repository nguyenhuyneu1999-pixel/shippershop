<?php
/**
 * ============================================
 * AUTHENTICATION API
 * ============================================
 * 
 * Endpoints:
 * POST /api/auth.php?action=register - Register new user
 * POST /api/auth.php?action=login - Login
 * POST /api/auth.php?action=logout - Logout
 * GET /api/auth.php?action=me - Get current user info
 */

define('APP_ACCESS', true);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Set CORS headers
setCorsHeaders();

// Get database
$db = db();

// Get action
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// ============================================
// REGISTER
// ============================================

if ($action === 'register') {
    if (getRequestMethod() !== 'POST') {
        error('Method not allowed', 405);
    }
    
    $input = getJsonInput();
    
    // Validate required fields
    $required = ['email', 'password', 'fullname'];
    $errors = validateRequired($required, $input);
    
    if (!empty($errors)) {
        error('Vui lòng điền đầy đủ thông tin', 400, $errors);
    }
    
    // Validate email
    if (!validateEmail($input['email'])) {
        error('Email không hợp lệ');
    }
    
    // Validate password
    $passwordCheck = validatePassword($input['password']);
    if ($passwordCheck !== true) {
        error('Mật khẩu không đủ mạnh', 400, ['password' => $passwordCheck]);
    }
    
    // Validate phone if provided
    if (!empty($input['phone']) && !validatePhone($input['phone'])) {
        error('Số điện thoại không hợp lệ');
    }
    
    // Check if email already exists
    $existing = $db->fetchOne("SELECT id FROM users WHERE email = ?", [sanitize($input['email'])]);
    
    if ($existing) {
        error('Email đã được sử dụng');
    }
    
    // Hash password
    $hashedPassword = hashPassword($input['password']);
    
    // Create user
    try {
        $db->beginTransaction();
        
        $userId = $db->insert('users', [
            'email' => sanitize($input['email']),
            'password' => $hashedPassword,
            'fullname' => sanitize($input['fullname']),
            'phone' => sanitize($input['phone'] ?? ''),
            'address' => sanitize($input['address'] ?? ''),
            'city' => sanitize($input['city'] ?? ''),
            'role' => 'user',
            'status' => 'active',
            'oauth_provider' => 'email'
        ]);
        
        // Create wallet for user
        $db->insert('wallet', [
            'user_id' => $userId,
            'balance' => 0
        ]);
        
        $db->commit();
        
        // Create session
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_email'] = $input['email'];
        $_SESSION['user_role'] = 'user';
        
        // Generate JWT token
        $token = generateJWT($userId, $input['email'], 'user');
        
        // Create session record
        $db->insert('sessions', [
            'user_id' => $userId,
            'token' => $token,
            'ip_address' => getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'expires_at' => date('Y-m-d H:i:s', time() + SESSION_LIFETIME)
        ]);
        
        success('Đăng ký thành công!', [
            'user' => [
                'id' => $userId,
                'email' => $input['email'],
                'fullname' => $input['fullname'],
                'role' => 'user'
            ],
            'token' => $token
        ]);
        
    } catch (Exception $e) {
        $db->rollback();
        
        if (DEBUG_MODE) {
            error('Đăng ký thất bại: ' . $e->getMessage(), 500);
        } else {
            error('Đăng ký thất bại. Vui lòng thử lại', 500);
        }
    }
}

// ============================================
// LOGIN
// ============================================

if ($action === 'login') {
    if (getRequestMethod() !== 'POST') {
        error('Method not allowed', 405);
    }
    
    $input = getJsonInput();
    
    // Validate required fields
    if (empty($input['email']) || empty($input['password'])) {
        error('Vui lòng nhập email và mật khẩu');
    }
    
    // Rate limiting
    if (!rateLimit('login_' . getClientIP(), 10, 3600)) {
        error('Quá nhiều lần thử. Vui lòng thử lại sau', 429);
    }
    
    // Get user
    $user = $db->fetchOne(
        "SELECT * FROM users WHERE email = ? AND status = 'active'",
        [sanitize($input['email'])]
    );
    
    if (!$user) {
        error('Email hoặc mật khẩu không đúng', 401);
    }
    
    // Verify password
    if (!verifyPassword($input['password'], $user['password'])) {
        error('Email hoặc mật khẩu không đúng', 401);
    }
    
    // Create session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    
    // Generate JWT token
    $token = generateJWT($user['id'], $user['email'], $user['role']);
    
    // Create session record
    $db->insert('sessions', [
        'user_id' => $user['id'],
        'token' => $token,
        'ip_address' => getClientIP(),
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'expires_at' => date('Y-m-d H:i:s', time() + SESSION_LIFETIME)
    ]);
    
    // Update last login
    $db->update('users',
        ['last_login' => date('Y-m-d H:i:s')],
        'id = ?',
        [$user['id']]
    );
    
    success('Đăng nhập thành công!', [
        'user' => [
            'id' => $user['id'],
            'email' => $user['email'],
            'fullname' => $user['fullname'],
            'phone' => $user['phone'],
            'avatar' => $user['avatar'],
            'role' => $user['role'],
            'membership_tier' => $user['membership_tier']
        ],
        'token' => $token
    ]);
}

// ============================================
// LOGOUT
// ============================================

if ($action === 'logout') {
    if (getRequestMethod() !== 'POST') {
        error('Method not allowed', 405);
    }
    
    // Delete sessions
    if (isset($_SESSION['user_id'])) {
        $db->hardDelete('sessions', 'user_id = ?', [$_SESSION['user_id']]);
    }
    
    // Destroy session
    session_destroy();
    
    success('Đăng xuất thành công');
}

// ============================================
// GET CURRENT USER
// ============================================

if ($action === 'me') {
    if (getRequestMethod() !== 'GET') {
        error('Method not allowed', 405);
    }
    
    requireAuth();
    
    $userId = getCurrentUserId();
    
    // Get user info
    $user = $db->fetchOne(
        "SELECT id, email, fullname, phone, avatar, bio, address, city, country, 
                role, membership_tier, membership_expires, created_at
         FROM users 
         WHERE id = ? AND status = 'active'",
        [$userId]
    );
    
    if (!$user) {
        error('User không tồn tại', 404);
    }
    
    // Get wallet balance
    $wallet = $db->fetchOne("SELECT balance FROM wallet WHERE user_id = ?", [$userId]);
    $user['wallet_balance'] = $wallet['balance'] ?? 0;
    
    // Get stats
    $stats = [
        'total_orders' => $db->count('orders', 'user_id = ?', [$userId]),
        'total_spent' => $db->fetchColumn(
            "SELECT SUM(total) FROM orders WHERE user_id = ? AND payment_status = 'paid'",
            [$userId]
        ) ?? 0,
        'cart_items' => $db->count('cart', 'user_id = ?', [$userId])
    ];
    
    $user['stats'] = $stats;
    
    success('Success', $user);
}

// ============================================
// UPDATE PROFILE
// ============================================

if ($action === 'update_profile') {
    if (getRequestMethod() !== 'POST') {
        error('Method not allowed', 405);
    }
    
    requireAuth();
    
    $userId = getCurrentUserId();
    $input = getJsonInput();
    
    // Allowed fields to update
    $allowedFields = ['fullname', 'phone', 'bio', 'address', 'city', 'country'];
    $updateData = [];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateData[$field] = sanitize($input[$field]);
        }
    }
    
    // Validate phone if provided
    if (isset($updateData['phone']) && !empty($updateData['phone']) && !validatePhone($updateData['phone'])) {
        error('Số điện thoại không hợp lệ');
    }
    
    if (empty($updateData)) {
        error('Không có dữ liệu để cập nhật');
    }
    
    // Update
    $db->update('users', $updateData, 'id = ?', [$userId]);
    
    success('Cập nhật thông tin thành công', $updateData);
}

// ============================================
// CHANGE PASSWORD
// ============================================

if ($action === 'change_password') {
    if (getRequestMethod() !== 'POST') {
        error('Method not allowed', 405);
    }
    
    requireAuth();
    
    $userId = getCurrentUserId();
    $input = getJsonInput();
    
    // Validate required fields
    if (empty($input['old_password']) || empty($input['new_password'])) {
        error('Vui lòng nhập mật khẩu cũ và mới');
    }
    
    // Get user
    $user = $db->fetchOne("SELECT password FROM users WHERE id = ?", [$userId]);
    
    // Verify old password
    if (!verifyPassword($input['old_password'], $user['password'])) {
        error('Mật khẩu cũ không đúng');
    }
    
    // Validate new password
    $passwordCheck = validatePassword($input['new_password']);
    if ($passwordCheck !== true) {
        error('Mật khẩu mới không đủ mạnh', 400, ['password' => $passwordCheck]);
    }
    
    // Hash and update
    $hashedPassword = hashPassword($input['new_password']);
    
    $db->update('users',
        ['password' => $hashedPassword],
        'id = ?',
        [$userId]
    );
    
    // Logout all other sessions
    $db->hardDelete('sessions', 'user_id = ?', [$userId]);
    
    success('Đổi mật khẩu thành công');
}

// Invalid action
error('Invalid action', 400);
