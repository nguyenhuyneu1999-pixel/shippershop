<?php
/**
 * ============================================
 * SHIPPERSHOP - DATABASE CONFIGURATION
 * ============================================
 * 
 * IMPORTANT: Change these values for your hosting
 */

// Prevent direct access
defined('APP_ACCESS') or define('APP_ACCESS', true);

// ============================================
// DATABASE CONFIGURATION
// ============================================

// Database credentials - CHANGE THESE!
define('DB_HOST', 'localhost');
define('DB_NAME', 'shippershop_db'); // Your database name
define('DB_USER', 'your_db_user');    // Your database username
define('DB_PASS', 'your_db_password'); // Your database password
define('DB_CHARSET', 'utf8mb4');

// ============================================
// SITE CONFIGURATION
// ============================================

define('SITE_URL', 'https://shippershop.vn');
define('SITE_NAME', 'ShipperShop');
define('SITE_EMAIL', 'support@shippershop.vn');
define('ADMIN_EMAIL', 'admin@shippershop.vn');

// ============================================
// SECURITY CONFIGURATION
// ============================================

// Secret keys - GENERATE NEW RANDOM STRINGS!
define('SECRET_KEY', 'your-secret-key-here-change-this-to-random-string');
define('PASSWORD_SALT', 'your-password-salt-here-change-this-to-random-string');
define('JWT_SECRET', 'your-jwt-secret-here-change-this-to-random-string');

// Session settings
define('SESSION_LIFETIME', 86400); // 24 hours in seconds
define('SESSION_NAME', 'SHIPPERSHOP_SESSION');

// Password requirements
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRE_UPPERCASE', true);
define('PASSWORD_REQUIRE_NUMBER', true);

// ============================================
// PAYMENT CONFIGURATION
// ============================================

define('SHIPPING_FEE', 30000); // 30,000 VND
define('FREE_SHIPPING_THRESHOLD', 500000); // Free ship from 500K

// Payment methods
define('PAYMENT_COD', 'cod');
define('PAYMENT_BANK', 'bank_transfer');
define('PAYMENT_WALLET', 'wallet');

// Bank transfer info
define('BANK_NAME', 'Vietcombank');
define('BANK_ACCOUNT', '1234567890');
define('BANK_OWNER', 'SHIPPERSHOP JSC');

// ============================================
// FILE UPLOAD CONFIGURATION
// ============================================

define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// ============================================
// API CONFIGURATION
// ============================================

define('API_RATE_LIMIT', 100); // requests per hour
define('API_PAGINATION_LIMIT', 50); // max items per page
define('API_DEFAULT_LIMIT', 12); // default items per page

// ============================================
// EMAIL CONFIGURATION (for future use)
// ============================================

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-app-password');
define('SMTP_ENCRYPTION', 'tls');

// ============================================
// OAUTH CONFIGURATION (for future use)
// ============================================

// Google OAuth
define('GOOGLE_CLIENT_ID', 'your-google-client-id');
define('GOOGLE_CLIENT_SECRET', 'your-google-client-secret');
define('GOOGLE_REDIRECT_URI', SITE_URL . '/api/auth/google/callback.php');

// Facebook OAuth
define('FACEBOOK_APP_ID', 'your-facebook-app-id');
define('FACEBOOK_APP_SECRET', 'your-facebook-app-secret');
define('FACEBOOK_REDIRECT_URI', SITE_URL . '/api/auth/facebook/callback.php');

// ============================================
// ERROR REPORTING
// ============================================

// Development mode - SET TO FALSE IN PRODUCTION!
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/../logs/error.log');
}

// ============================================
// TIMEZONE
// ============================================

date_default_timezone_set('Asia/Ho_Chi_Minh');

// ============================================
// SESSION CONFIGURATION
// ============================================

// Secure session settings
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1); // Only if using HTTPS
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

// ============================================
// CORS CONFIGURATION
// ============================================

// Allowed origins for CORS
define('ALLOWED_ORIGINS', [
    'https://shippershop.vn',
    'http://localhost:3000', // For development
]);

// Set CORS headers
function setCorsHeaders() {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    
    if (in_array($origin, ALLOWED_ORIGINS)) {
        header("Access-Control-Allow-Origin: $origin");
    }
    
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // 24 hours
    
    // Handle preflight requests
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}

// ============================================
// AUTOLOAD CLASSES (simple autoloader)
// ============================================

spl_autoload_register(function($class) {
    $file = __DIR__ . '/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Generate random string
 */
function generateRandomString($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Hash password securely
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate JWT token (simple implementation)
 */
function generateJWT($userId, $email, $role = 'user') {
    $header = base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    
    $payload = base64_encode(json_encode([
        'user_id' => $userId,
        'email' => $email,
        'role' => $role,
        'iat' => time(),
        'exp' => time() + SESSION_LIFETIME
    ]));
    
    $signature = base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    
    return "$header.$payload.$signature";
}

/**
 * Verify JWT token
 */
function verifyJWT($token) {
    $parts = explode('.', $token);
    
    if (count($parts) !== 3) {
        return false;
    }
    
    list($header, $payload, $signature) = $parts;
    
    $validSignature = base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    
    if ($signature !== $validSignature) {
        return false;
    }
    
    $data = json_decode(base64_decode($payload), true);
    
    if ($data['exp'] < time()) {
        return false;
    }
    
    return $data;
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Get current user ID
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Require authentication
 */
function requireAuth() {
    if (!isLoggedIn()) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'Authentication required'
        ]);
        exit;
    }
}

/**
 * Require admin role
 */
function requireAdmin() {
    requireAuth();
    
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'message' => 'Admin access required'
        ]);
        exit;
    }
}

// ============================================
// INITIALIZATION COMPLETE
// ============================================

// Config loaded successfully
return true;
