<?php
/**
 * SHIPPERSHOP - AUTO SETUP WIZARD
 * Chạy file này 1 lần để cài đặt tự động
 * XÓA file này sau khi cài đặt xong!
 */

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

// Xử lý form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step == 1) {
        // Kiểm tra kết nối DB
        $host = trim($_POST['db_host'] ?? 'localhost');
        $user = trim($_POST['db_user'] ?? '');
        $pass = trim($_POST['db_pass'] ?? '');
        $name = trim($_POST['db_name'] ?? '');

        try {
            $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Tạo database nếu chưa có
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$name`");

            // Lưu vào session để dùng bước sau
            session_start();
            $_SESSION['setup_db'] = compact('host', 'user', 'pass', 'name');

            header('Location: setup.php?step=2');
            exit;
        } catch (Exception $e) {
            $error = "❌ Lỗi kết nối: " . $e->getMessage();
        }
    }

    if ($step == 2) {
        session_start();
        $db = $_SESSION['setup_db'];
        try {
            $pdo = new PDO("mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4", $db['user'], $db['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Tạo tất cả bảng
            $sql = file_get_contents(__DIR__ . '/database.sql');
            // Bỏ comments và chạy từng lệnh
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $stmt) {
                if (!empty($stmt) && !preg_match('/^--/', $stmt)) {
                    try { $pdo->exec($stmt); } catch(Exception $e) {}
                }
            }

            // Import social tables
            if (file_exists(__DIR__ . '/social-tables.sql')) {
                $sql2 = file_get_contents(__DIR__ . '/social-tables.sql');
                $stmts2 = array_filter(array_map('trim', explode(';', $sql2)));
                foreach ($stmts2 as $s) {
                    if (!empty($s) && !preg_match('/^--/', $s)) {
                        try { $pdo->exec($s); } catch(Exception $e) {}
                    }
                }
            }

            // Import wallet tables
            if (file_exists(__DIR__ . '/wallet-tables.sql')) {
                $sql3 = file_get_contents(__DIR__ . '/wallet-tables.sql');
                $stmts3 = array_filter(array_map('trim', explode(';', $sql3)));
                foreach ($stmts3 as $s) {
                    if (!empty($s) && !preg_match('/^--/', $s)) {
                        try { $pdo->exec($s); } catch(Exception $e) {}
                    }
                }
            }

            header('Location: setup.php?step=3');
            exit;
        } catch (Exception $e) {
            $error = "❌ Lỗi tạo bảng: " . $e->getMessage();
        }
    }

    if ($step == 3) {
        session_start();
        $db = $_SESSION['setup_db'];
        try {
            $pdo = new PDO("mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4", $db['user'], $db['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $adminName  = trim($_POST['admin_name'] ?? 'Admin');
            $adminEmail = trim($_POST['admin_email'] ?? '');
            $adminPass  = trim($_POST['admin_pass'] ?? '');
            $siteUrl    = rtrim(trim($_POST['site_url'] ?? 'https://shippershop.vn'), '/');

            if (empty($adminEmail) || empty($adminPass)) {
                throw new Exception("Vui lòng nhập đầy đủ email và mật khẩu admin!");
            }

            $hash = password_hash($adminPass, PASSWORD_BCRYPT);

            // Xóa admin cũ nếu có
            $pdo->exec("DELETE FROM users WHERE role='admin'");

            // Tạo admin mới
            $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, phone, role, status, created_at) VALUES (?, ?, ?, '0000000000', 'admin', 'active', NOW())");
            $stmt->execute([$adminName, $adminEmail, $hash]);
            $adminId = $pdo->lastInsertId();

            // Tạo wallet cho admin
            try {
                $pdo->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, 0)")->execute([$adminId]);
            } catch(Exception $e) {}

            // Thêm sản phẩm mẫu
            $products = [
                ['iPhone 15 Pro Max', 'Điện Thoại', 28990000, 44990000, 50, 'iPhone 15 Pro Max mới nhất với chip A17 Pro, camera 48MP và màn hình Super Retina XDR 6.7 inch', 'dien-thoai'],
                ['MacBook Air M2', 'Laptop', 22990000, 28990000, 30, 'MacBook Air với chip M2 mạnh mẽ, pin 18 giờ, màn hình Liquid Retina 13.6 inch', 'laptop'],
                ['Samsung Galaxy S24 Ultra', 'Điện Thoại', 26990000, 32990000, 45, 'Samsung Galaxy S24 Ultra với bút S Pen, camera 200MP và AI tích hợp', 'dien-thoai'],
                ['Nike Air Max 270', 'Thời Trang', 1990000, 3990000, 100, 'Giày thể thao Nike Air Max 270 với đệm khí lớn nhất, thiết kế thời trang', 'giay-dep'],
                ['Apple Watch Series 9', 'Điện Tử', 9990000, 13490000, 60, 'Apple Watch S9 với màn hình sáng gấp đôi, chip S9 mới và tính năng Double Tap', 'dien-tu'],
                ['AirPods Pro 2nd Gen', 'Âm Thanh', 5490000, 7990000, 80, 'AirPods Pro thế hệ 2 với chống ồn chủ động ANC, âm thanh Spatial Audio', 'am-thanh'],
                ['Áo Thun Nam Basic', 'Thời Trang', 199000, 350000, 200, 'Áo thun nam basic chất liệu cotton 100%, nhiều màu sắc', 'thoi-trang'],
                ['Nồi Chiên Không Dầu 5L', 'Gia Dụng', 1290000, 1890000, 40, 'Nồi chiên không dầu 5L công suất 1700W, màn hình cảm ứng LED', 'gia-dung'],
                ['Son Dưỡng Môi Laneige', 'Mỹ Phẩm', 350000, 450000, 150, 'Son dưỡng môi Laneige Lip Sleeping Mask dưỡng ẩm suốt đêm', 'my-pham'],
                ['Kem Chống Nắng Anessa', 'Mỹ Phẩm', 450000, 580000, 120, 'Kem chống nắng Anessa Perfect UV Sunscreen SPF50+ PA++++', 'my-pham'],
            ];

            foreach ($products as $p) {
                try {
                    $stmt = $pdo->prepare("INSERT INTO products (name, category, price, original_price, stock, description, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW()) ON DUPLICATE KEY UPDATE name=name");
                    $stmt->execute($p);
                } catch(Exception $e) {}
            }

            // Cập nhật config.php
            $secretKey = bin2hex(random_bytes(16));
            $jwtSecret = bin2hex(random_bytes(16));
            $salt = bin2hex(random_bytes(8));

            $configContent = "<?php
/**
 * SHIPPERSHOP - DATABASE CONFIGURATION
 * Auto-generated by Setup Wizard
 */

defined('APP_ACCESS') or define('APP_ACCESS', true);

// DATABASE
define('DB_HOST', '{$db['host']}');
define('DB_NAME', '{$db['name']}');
define('DB_USER', '{$db['user']}');
define('DB_PASS', '{$db['pass']}');
define('DB_CHARSET', 'utf8mb4');

// SITE
define('SITE_URL', '$siteUrl');
define('SITE_NAME', 'ShipperShop');
define('SITE_EMAIL', 'support@shippershop.vn');
define('ADMIN_EMAIL', '$adminEmail');

// SECURITY
define('SECRET_KEY', '$secretKey');
define('PASSWORD_SALT', '$salt');
define('JWT_SECRET', '$jwtSecret');
define('SESSION_LIFETIME', 86400);
define('SESSION_NAME', 'SHIPPERSHOP_SESSION');
define('PASSWORD_MIN_LENGTH', 6);
define('PASSWORD_REQUIRE_UPPERCASE', false);
define('PASSWORD_REQUIRE_NUMBER', false);

// PAYMENT
define('SHIPPING_FEE', 30000);
define('FREE_SHIPPING_THRESHOLD', 500000);
define('PAYMENT_COD', 'cod');
define('PAYMENT_BANK', 'bank_transfer');
define('PAYMENT_WALLET', 'wallet');
define('BANK_NAME', 'Vietcombank');
define('BANK_ACCOUNT', '1234567890');
define('BANK_OWNER', 'SHIPPERSHOP JSC');

// UPLOAD
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

// API
define('API_RATE_LIMIT', 200);
define('API_PAGINATION_LIMIT', 50);
define('API_DEFAULT_LIMIT', 12);

// ERROR
define('DEBUG_MODE', false);
error_reporting(0);
ini_set('display_errors', 0);

// TIMEZONE
date_default_timezone_set('Asia/Ho_Chi_Minh');

// SESSION
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

// CORS
define('ALLOWED_ORIGINS', ['$siteUrl', 'https://www.$siteUrl']);

function setCorsHeaders() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Access-Control-Allow-Credentials: true');
    if (\$_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
}

function generateRandomString(\$length = 32) { return bin2hex(random_bytes(\$length / 2)); }
function hashPassword(\$password) { return password_hash(\$password, PASSWORD_BCRYPT); }
function verifyPassword(\$password, \$hash) { return password_verify(\$password, \$hash); }
function isLoggedIn() { return isset(\$_SESSION['user_id']) && !empty(\$_SESSION['user_id']); }
function getCurrentUserId() { return \$_SESSION['user_id'] ?? null; }
function isAdmin() { return isset(\$_SESSION['user_role']) && \$_SESSION['user_role'] === 'admin'; }

function requireAuth() {
    if (!isLoggedIn()) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Vui lòng đăng nhập']);
        exit;
    }
}

function requireAdmin() {
    requireAuth();
    if (!isAdmin()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Không có quyền admin']);
        exit;
    }
}

function generateJWT(\$userId, \$email, \$role = 'user') {
    \$header = base64_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    \$payload = base64_encode(json_encode(['user_id' => \$userId, 'email' => \$email, 'role' => \$role, 'iat' => time(), 'exp' => time() + SESSION_LIFETIME]));
    \$signature = base64_encode(hash_hmac('sha256', \"\$header.\$payload\", JWT_SECRET, true));
    return \"\$header.\$payload.\$signature\";
}

function verifyJWT(\$token) {
    \$parts = explode('.', \$token);
    if (count(\$parts) !== 3) return false;
    list(\$header, \$payload, \$signature) = \$parts;
    \$validSig = base64_encode(hash_hmac('sha256', \"\$header.\$payload\", JWT_SECRET, true));
    if (\$signature !== \$validSig) return false;
    \$data = json_decode(base64_decode(\$payload), true);
    if (\$data['exp'] < time()) return false;
    return \$data;
}

return true;
";
            file_put_contents(__DIR__ . '/includes/config.php', $configContent);

            $_SESSION['setup_done'] = [
                'admin_email' => $adminEmail,
                'admin_pass' => $adminPass,
                'site_url' => $siteUrl
            ];

            header('Location: setup.php?step=4');
            exit;
        } catch (Exception $e) {
            $error = "❌ Lỗi: " . $e->getMessage();
        }
    }
}

if ($step == 4) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ShipperShop - Setup Wizard</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: linear-gradient(135deg, #EE4D2D 0%, #ff7043 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
.setup-card { background: white; border-radius: 20px; padding: 40px; width: 100%; max-width: 580px; box-shadow: 0 20px 60px rgba(0,0,0,0.2); }
.logo { text-align: center; font-size: 28px; font-weight: 900; margin-bottom: 8px; }
.logo span { color: #EE4D2D; }
.subtitle { text-align: center; color: #888; margin-bottom: 30px; font-size: 14px; }
.steps { display: flex; justify-content: center; gap: 8px; margin-bottom: 35px; }
.step-dot { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; }
.step-dot.active { background: #EE4D2D; color: white; }
.step-dot.done { background: #00C851; color: white; }
.step-dot.pending { background: #eee; color: #999; }
.step-line { width: 40px; height: 2px; background: #eee; align-self: center; }
.step-line.done { background: #00C851; }
h2 { font-size: 22px; margin-bottom: 8px; }
p.desc { color: #666; margin-bottom: 25px; font-size: 14px; line-height: 1.6; }
.form-group { margin-bottom: 18px; }
label { display: block; font-weight: 600; margin-bottom: 6px; font-size: 14px; }
input[type=text], input[type=password], input[type=email], input[type=url] {
    width: 100%; padding: 12px 15px; border: 2px solid #eee; border-radius: 10px;
    font-size: 15px; outline: none; transition: border 0.2s;
}
input:focus { border-color: #EE4D2D; }
.hint { font-size: 12px; color: #999; margin-top: 4px; }
.btn { width: 100%; padding: 15px; background: #EE4D2D; color: white; border: none; border-radius: 10px; font-size: 16px; font-weight: 700; cursor: pointer; margin-top: 10px; }
.btn:hover { background: #D73211; }
.btn-success { background: #00C851; }
.btn-success:hover { background: #00a843; }
.error { background: #fff5f5; border: 2px solid #ff3b30; color: #c00; padding: 12px 15px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; }
.success-icon { font-size: 80px; text-align: center; margin-bottom: 20px; }
.info-box { background: #f8f9fa; border-radius: 12px; padding: 18px; margin-bottom: 15px; }
.info-box h4 { font-size: 14px; color: #333; margin-bottom: 10px; }
.info-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; }
.info-label { color: #666; }
.info-value { font-weight: 600; font-family: monospace; background: #eee; padding: 2px 8px; border-radius: 4px; }
.warning { background: #fff8e1; border: 2px solid #FFB900; border-radius: 10px; padding: 15px; margin-top: 20px; font-size: 13px; color: #856404; }
</style>
</head>
<body>
<div class="setup-card">
    <div class="logo">🛒 SHIPPER<span>SHOP</span></div>
    <div class="subtitle">Trình cài đặt tự động</div>

    <!-- Progress Steps -->
    <div class="steps">
        <div class="step-dot <?= $step >= 1 ? ($step > 1 ? 'done' : 'active') : 'pending' ?>">1</div>
        <div class="step-line <?= $step > 1 ? 'done' : '' ?>"></div>
        <div class="step-dot <?= $step >= 2 ? ($step > 2 ? 'done' : 'active') : 'pending' ?>">2</div>
        <div class="step-line <?= $step > 2 ? 'done' : '' ?>"></div>
        <div class="step-dot <?= $step >= 3 ? ($step > 3 ? 'done' : 'active') : 'pending' ?>">3</div>
        <div class="step-line <?= $step > 3 ? 'done' : '' ?>"></div>
        <div class="step-dot <?= $step >= 4 ? 'done' : 'pending' ?>">4</div>
    </div>

    <?php if ($error): ?>
    <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <?php if ($step == 1): ?>
    <h2>🗄️ Kết nối Database</h2>
    <p class="desc">Nhập thông tin database MySQL từ cPanel → MySQL Databases</p>
    <form method="POST">
        <div class="form-group">
            <label>Host</label>
            <input type="text" name="db_host" value="localhost" placeholder="localhost">
        </div>
        <div class="form-group">
            <label>Tên Database</label>
            <input type="text" name="db_name" placeholder="nhshiw2j_shippershop" required>
            <div class="hint">Tạo database mới trong cPanel → MySQL Databases trước</div>
        </div>
        <div class="form-group">
            <label>Username Database</label>
            <input type="text" name="db_user" placeholder="nhshiw2j_shopuser" required>
        </div>
        <div class="form-group">
            <label>Password Database</label>
            <input type="password" name="db_pass" placeholder="••••••••" required>
        </div>
        <button type="submit" class="btn">Tiếp theo →</button>
    </form>

    <?php elseif ($step == 2): ?>
    <h2>⚙️ Đang tạo bảng dữ liệu...</h2>
    <p class="desc">Hệ thống đang tạo tất cả bảng cần thiết trong database</p>
    <form method="POST">
        <div class="info-box">
            <h4>Sẽ tạo các bảng:</h4>
            <div style="color:#666;font-size:13px;line-height:2;">
                ✅ users - Tài khoản người dùng<br>
                ✅ products - Sản phẩm<br>
                ✅ orders + order_items - Đơn hàng<br>
                ✅ cart - Giỏ hàng<br>
                ✅ posts + comments + likes - Bài viết xã hội<br>
                ✅ wallets + wallet_transactions - Ví tiền<br>
                ✅ follows + notifications - Theo dõi & thông báo
            </div>
        </div>
        <button type="submit" class="btn">Tạo bảng ngay →</button>
    </form>

    <?php elseif ($step == 3): ?>
    <h2>👤 Tạo tài khoản Admin</h2>
    <p class="desc">Tài khoản này để quản lý toàn bộ hệ thống</p>
    <form method="POST">
        <div class="form-group">
            <label>URL Website</label>
            <input type="text" name="site_url" value="https://shippershop.vn" required>
        </div>
        <div class="form-group">
            <label>Tên Admin</label>
            <input type="text" name="admin_name" value="Admin ShipperShop" required>
        </div>
        <div class="form-group">
            <label>Email Admin</label>
            <input type="email" name="admin_email" placeholder="admin@shippershop.vn" required>
        </div>
        <div class="form-group">
            <label>Mật khẩu Admin</label>
            <input type="password" name="admin_pass" placeholder="Tối thiểu 6 ký tự" required>
        </div>
        <button type="submit" class="btn">Hoàn thành cài đặt ✓</button>
    </form>

    <?php elseif ($step == 4): ?>
    <?php $done = $_SESSION['setup_done'] ?? []; ?>
    <div class="success-icon">🎉</div>
    <h2 style="text-align:center;color:#00C851;">Cài đặt thành công!</h2>
    <p class="desc" style="text-align:center;">ShipperShop đã sẵn sàng hoạt động với đầy đủ chức năng</p>

    <div class="info-box">
        <h4>📧 Thông tin đăng nhập Admin:</h4>
        <div class="info-row">
            <span class="info-label">Email:</span>
            <span class="info-value"><?= htmlspecialchars($done['admin_email'] ?? '') ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Mật khẩu:</span>
            <span class="info-value"><?= htmlspecialchars($done['admin_pass'] ?? '') ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Trang admin:</span>
            <span class="info-value">/admin.html</span>
        </div>
    </div>

    <div class="info-box">
        <h4>✅ Đã cài đặt:</h4>
        <div style="font-size:13px;color:#555;line-height:2;">
            ✅ Cơ sở dữ liệu & tất cả bảng<br>
            ✅ 10 sản phẩm mẫu<br>
            ✅ Tài khoản Admin<br>
            ✅ config.php được cập nhật tự động<br>
            ✅ Ví tiền & thanh toán<br>
            ✅ Hệ thống bài viết cộng đồng
        </div>
    </div>

    <a href="index.html" class="btn btn-success" style="display:block;text-align:center;text-decoration:none;padding:15px;border-radius:10px;">
        🚀 Vào trang chủ ShipperShop
    </a>

    <div class="warning">
        ⚠️ <strong>QUAN TRỌNG:</strong> Xóa file <strong>setup.php</strong> ngay sau khi cài đặt xong để bảo mật!
    </div>
    <?php endif; ?>
</div>
</body>
</html>
